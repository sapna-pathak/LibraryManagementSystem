import dao.studentDAO;
import model.Student;
import java.time.LocalDate;
import java.util.Scanner;
import dao.BookDAO;
import dao.IssueDAO;
import model.Book;
import model.Issue;

public class Main {
    public static void main(String[] args) {
        studentDAO studentDAO = new studentDAO();
        BookDAO bookDAO = new BookDAO();
        IssueDAO issueDAO = new IssueDAO();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Student Library System ---");
            System.out.println("1. Add Student");
            System.out.println("2. View All Students");
            System.out.println("3. Search Student by ID");
            System.out.println("4. Update Student");
            System.out.println("5. Delete Student");
            System.out.println("6. Add Book");
            System.out.println("7. View All Books");
            System.out.println("8. Update Books");
            System.out.println("9. Issue Book");
            System.out.println("10. View All Issues");
            System.out.println("11. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                // Student Operations
                case 1:
                    Student student = new Student();
                    System.out.print("Enter First Name: ");
                    student.setFirstName(scanner.next());
                    System.out.print("Enter Last Name: ");
                    student.setLastName(scanner.next());
                    System.out.print("Enter Email: ");
                    student.setEmail(scanner.next());
                    System.out.print("Enter Phone Number: ");
                    student.setPhoneNumber(scanner.next());
                    System.out.print("Enter Address: ");
                    student.setAddress(scanner.next());
                    studentDAO.insertStudent(student);
                    System.out.println("Student added successfully.");
                    break;

                case 2:
                    studentDAO.getAllStudents().forEach(s -> {
                        System.out.println(s.getStudentId() + " | " + s.getFirstName() + " " + s.getLastName() + " | " + s.getEmail()+" | "+s.getAddress()+" | " + s.getPhoneNumber());
                    });
                    break;

                case 3:
                    System.out.print("Enter Student ID: ");
                    int id = scanner.nextInt();
                    Student searchedStudent = studentDAO.getStudentById(id);
                    if (searchedStudent != null) {
                        System.out.println("Found: " + searchedStudent.getFirstName() + " " + searchedStudent.getLastName());
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;

                case 4:
                    System.out.print("Enter Student ID: ");
                    int updateId = scanner.nextInt();
                    Student studentToUpdate = studentDAO.getStudentById(updateId);
                    if (studentToUpdate != null) {
                        System.out.print("Enter New First Name: ");
                        studentToUpdate.setFirstName(scanner.next());
                        System.out.print("Enter New Last Name: ");
                        studentToUpdate.setLastName(scanner.next());
                        System.out.print("Enter New Email: ");
                        studentToUpdate.setEmail(scanner.next());
                        System.out.print("Enter New Phone Number: ");
                        studentToUpdate.setPhoneNumber(scanner.next());
                        System.out.print("Enter New Address: ");
                        studentToUpdate.setAddress(scanner.next());
                        studentDAO.updateStudent(studentToUpdate);
                        System.out.println("Student updated successfully.");
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;

                case 5:
                    System.out.print("Enter Student ID to Delete: ");
                    int deleteId = scanner.nextInt();
                    studentDAO.deleteStudent(deleteId);
                    System.out.println("Student deleted successfully.");
                    break;

                // Book Operations
                case 6:
                    Book book = new Book();
                    System.out.print("Enter Book Name: ");
                    book.setBookName(scanner.next());
                    System.out.print("Enter Author Name: ");
                    book.setAuthorName(scanner.next());
                    System.out.print("Enter Publisher: ");
                    book.setPublisher(scanner.next());
                    bookDAO.insertBook(book);
                    System.out.println("Book added successfully.");
                    break;

                case 7:
                    bookDAO.getAllBooks().forEach(b -> {
                        System.out.println(b.getBookId() + " | " + b.getBookName() + " | " + b.getAuthorName() + " | " + b.getPublisher());
                    });
                    break;
                    
                case 8:
                	 System.out.print("Enter book ID: ");
                     int Id = scanner.nextInt();
                     Book BookToUpdate = bookDAO.getBookById(Id);
                     if (BookToUpdate != null) {
                         System.out.print("Enter New book Name: ");
                         BookToUpdate.setBookName(scanner.next());
                         System.out.print("Enter New Author Name: ");
                         BookToUpdate.setAuthorName(scanner.next());
                         System.out.print("Enter New Publisher Name: ");
                         BookToUpdate.setPublisher(scanner.next());
                         bookDAO.updateBook(BookToUpdate);
                         System.out.println("Book updated successfully.");
                     } else {
                         System.out.println("Book not found.");
                     }
                     break;

                // Issue Operations

                case 9:
               Issue issue = new Issue();
               System.out.print("Enter Student ID: ");
               int studentId = scanner.nextInt();
               System.out.print("Enter Book ID: ");
               int bookId = scanner.nextInt();

               // Fetch the student and book objects from the database using the IDs
               Student student3 = studentDAO.getStudentById(studentId);
               Book book3 = bookDAO.getBookById(bookId);

               if (student3 != null && book3 != null) {
               issue.setStudent(student3);
               issue.setBook(book3);
       
               // Get the issue date from the user and convert it to java.sql.Date
               System.out.print("Enter Issue Date (yyyy-mm-dd): ");
               String issueDateStr = scanner.next();  // Get date in string format
               java.sql.Date issueDate = java.sql.Date.valueOf(issueDateStr);  // Convert string to java.sql.Date
                      
                      // Convert java.sql.Date to java.time.LocalDate
               LocalDate issueLocalDate = issueDate.toLocalDate();
               issue.setIssueDate(issueLocalDate);  // Set the LocalDate

               // Get the due date from the user and convert it to java.sql.Date
               System.out.print("Enter Due Date (yyyy-mm-dd): ");
               String dueDateStr = scanner.next();  // Get date in string format
               java.sql.Date dueDate = java.sql.Date.valueOf(dueDateStr);  // Convert string to java.sql.Date
               
               // Convert java.sql.Date to java.time.LocalDate
               LocalDate dueLocalDate = dueDate.toLocalDate();
               issue.setDueDate(dueLocalDate);  // Set the LocalDate
       
                      // Set the issue status to 'Issued'
               issue.setStatus("Issued");

               // Insert the issue record into the database
               issueDAO.insertIssue(issue);
               System.out.println("Book issued successfully.");
               } else {
               System.out.println("Invalid Student or Book ID.");
               }
               break;

                case 10:
                    issueDAO.getAllIssues().forEach(i -> {
                        System.out.println(i.getIssueId() + " | " + i.getStudent().getFirstName() + " " + i.getStudent().getLastName() +
                                           " | " + i.getBook().getBookName() + " | " + i.getStatus());
                    });
                    break;
               

                case 11:
                    scanner.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}

