package dao;

public class BookDAO {

}
