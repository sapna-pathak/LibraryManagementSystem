package dao;


import model.Issue;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class IssueDAO {
    private SessionFactory factory;

    public IssueDAO() {
        factory = new Configuration().configure().buildSessionFactory();
    }

    // Insert a new issue record
    public void insertIssue(Issue issue) {
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        session.save(issue);
        tx.commit();
        session.close();
    }

    // Get all issue records
    public List<Issue> getAllIssues() {
        Session session = factory.openSession();
        List<Issue> issues = session.createQuery("FROM Issue", Issue.class).list();
        session.close();
        return issues;
    }

    // Get an issue record by ID
    public Issue getIssueById(int id) {
        Session session = factory.openSession();
        Issue issue = session.get(Issue.class, id);
        session.close();
        return issue;
    }

    // Update issue information
    public void updateIssue(Issue issue) {
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        session.update(issue);
        tx.commit();
        session.close();
    }

    // Delete an issue record
    public void deleteIssue(int id) {
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        Issue issue = session.get(Issue.class, id);
        if (issue != null) {
            session.delete(issue);
        }
        tx.commit();
        session.close();
    }
}
