

import dao.studentDAO;
import model.Student;
import java.util.Scanner;
import dao.BookDAO;
import dao.IssueDAO;

import model.Book;
import model.Issue;

public class Main {
    public static void main(String[] args) {
        studentDAO studentDAO = new studentDAO();
        BookDAO bookDAO = new BookDAO();
        IssueDAO issueDAO = new IssueDAO();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Student Library System ---");
            System.out.println("1. Add Student");
            System.out.println("2. View All Students");
            System.out.println("3. Search Student by ID");
            System.out.println("4. Update Student");
            System.out.println("5. Delete Student");
            System.out.println("6. Add Book");
            System.out.println("7. View All Books");
            System.out.println("8. Issue Book");
            System.out.println("9. View All Issues");
            System.out.println("10. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                // Student Operations
                case 1:
                    Student student = new Student();
                    System.out.print("Enter First Name: ");
                    student.setFirstName(scanner.next());
                    System.out.print("Enter Last Name: ");
                    student.setLastName(scanner.next());
                    System.out.print("Enter Email: ");
                    student.setEmail(scanner.next());
                    System.out.print("Enter Phone Number: ");
                    student.setPhoneNumber(scanner.next());
                    System.out.print("Enter Address: ");
                    student.setAddress(scanner.next());
                    studentDAO.insertStudent(student);
                    System.out.println("Student added successfully.");
                    break;

//                case 2:
//                    studentDAO.getAllStudents().forEach(s -> {
//                        System.out.println(s.getStudentId() + " | " + s.getFirstName() + " " + s.getLastName() + " | " + s.getEmail());
//                    });
//                    break;

                case 3:
                    System.out.print("Enter Student ID: ");
                    int id = scanner.nextInt();
                    Student searchedStudent = studentDAO.getStudentById(id);
                    if (searchedStudent != null) {
                        System.out.println("Found: " + searchedStudent.getFirstName() + " " + searchedStudent.getLastName());
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;

                case 4:
                    System.out.print("Enter Student ID: ");
                    int updateId = scanner.nextInt();
                    Student studentToUpdate = studentDAO.getStudentById(updateId);
                    if (studentToUpdate != null) {
                        System.out.print("Enter New First Name: ");
                        studentToUpdate.setFirstName(scanner.next());
                        System.out.print("Enter New Last Name: ");
                        studentToUpdate.setLastName(scanner.next());
                        System.out.print("Enter New Email: ");
                        studentToUpdate.setEmail(scanner.next());
                        System.out.print("Enter New Phone Number: ");
                        studentToUpdate.setPhoneNumber(scanner.next());
                        System.out.print("Enter New Address: ");
                        studentToUpdate.setAddress(scanner.next());
                        studentDAO.updateStudent(studentToUpdate);
                        System.out.println("Student updated successfully.");
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;

                case 5:
                    System.out.print("Enter Student ID to Delete: ");
                    int deleteId = scanner.nextInt();
                    studentDAO.deleteStudent(deleteId);
                    System.out.println("Student deleted successfully.");
                    break;

                // Book Operations
                case 6:
                    Book book = new Book();
                    System.out.print("Enter Book Name: ");
                    book.setBookName(scanner.next());
                    System.out.print("Enter Author Name: ");
                    book.setAuthorName(scanner.next());
                    System.out.print("Enter Publisher: ");
                    book.setPublisher(scanner.next());
                    System.out.print("Enter Publication Year: ");
                    book.setPublicationYear(scanner.nextInt());
                    System.out.print("Enter ISBN: ");
                    book.setIsbn(scanner.next());
                    System.out.print("Enter Availability Status: ");
                    book.setAvailabilityStatus(scanner.next());
                  //  bookDAO.insertBook(book);
                    System.out.println("Book added successfully.");
                    break;

//                case 7:
//                    bookDAO.getAllBooks().forEach(b -> {
//                        System.out.println(b.getBookId() + " | " + b.getBookName() + " | " + b.getAuthorName() + " | " + b.getIsbn());
//                    });
//                    break;

                // Issue Operations
                case 8:
                    Issue issue = new Issue();
                    System.out.print("Enter Student ID: ");
                    int studentId = scanner.nextInt();
                    System.out.print("Enter Book ID: ");
                    int bookId = scanner.nextInt();
                    issue.setStudent(studentDAO.getStudentById(studentId));
                   // issue.setBook(bookDAO.getBookById(bookId));
                    System.out.print("Enter Issue Date (yyyy-mm-dd): ");
                    String issueDate = scanner.next(); // You can convert it to a Date type as needed
                    issue.setIssueDate(java.sql.Date.valueOf(issueDate));
                    System.out.print("Enter Due Date (yyyy-mm-dd): ");
                    String dueDate = scanner.next(); // Same for due date
                    issue.setDueDate(java.sql.Date.valueOf(dueDate));
                    issue.setStatus("Issued");
                    issueDAO.insertIssue(issue);
                    System.out.println("Book issued successfully.");
                    break;

//                case 9:
//                    issueDAO.getAllIssues().forEach(i -> {
//                        System.out.println(i.getIssueId() + " | " + i.getStudent().getFirstName() + " " + i.getStudent().getLastName() +
//                                           " | " + i.getBook().getBookName() + " | " + i.getStatus());
//                    });
//                    break;

                case 10:
                    scanner.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
